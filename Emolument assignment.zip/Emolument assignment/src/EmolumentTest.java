import javax.swing.JOptionPane;

public class EmolumentTest {
    public static void main(String[] args) {
        String basicSalaryStr = JOptionPane.showInputDialog("Enter Basic Salary:");
        String taxReliefStr = JOptionPane.showInputDialog("Enter Tax Relief:");

        double basicSalary = Double.parseDouble(basicSalaryStr);
        double taxRelief = Double.parseDouble(taxReliefStr);

        MyEmolument Staff_Salary = new MyEmolument(basicSalary, taxRelief);

        String output = "Basic Salary: " + Staff_Salary.getBasicSalary() + "\n" +
                "Tax Relief: " + Staff_Salary.getTaxRelief() + "\n" +
                "SSNIT Contribution: " + Staff_Salary.SSNIT() + "\n" +
                "Taxable Income: " + Staff_Salary.taxableIncome() + "\n" +
                "Income Tax: " + Staff_Salary.incomeTax() + "\n" +
                "Total Deduction: " + Staff_Salary.totalDeduction() + "\n" +
                "Net Salary: " + Staff_Salary.netSalary();

        JOptionPane.showMessageDialog(null, output);
    }
}