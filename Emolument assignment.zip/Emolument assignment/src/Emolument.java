public class Emolument {
    double basicSalary;
    private double taxRelief;

    // i. Constructor with parameters
    public Emolument(double basicSalary, double taxRelief) {
        this.basicSalary = basicSalary;
        this.taxRelief = taxRelief;
    }

    // iii. Getter for basicSalary
    public double getBasicSalary() {
        return basicSalary;
    }

    // iv. Getter for taxRelief
    public double getTaxRelief() {
        return taxRelief;
    }

    // v. Calculate SSNIT contribution (3.5% of basic salary)
    public double SSNIT() {
        return 0.035 * basicSalary;
    }

    // vi. Calculate taxable income
    public double taxableIncome() {
        return basicSalary - (taxRelief + SSNIT());
    }
}

class MyEmolument extends Emolument {
    // i. Data fields (inherited from Emolument)

    // ii. Default constructor
    public MyEmolument() {
        super(0, 0); // Call parent constructor with default values
    }

    // iii. Constructor with parameters
    public MyEmolument(double basicSalary, double taxRelief) {
        super(basicSalary, taxRelief);
    }

    // iv. Calculate income tax
    public double incomeTax() {
        double taxableIncome = taxableIncome();
        double tax = 0.0;

        if (taxableIncome <= 500) {
            tax = taxableIncome * 0.05;
        } else if (taxableIncome <= 1000) {
            tax = 500 * 0.05 + (taxableIncome - 500) * 0.125;
        } else {
            tax = 500 * 0.05 + 500 * 0.125 + (taxableIncome - 1000) * 0.175;
        }

        return tax;
    }

    // v. Calculate total deduction
    public double totalDeduction() {
        return SSNIT() + incomeTax();
    }

    // vi. Calculate net salary
    public double netSalary() {
        return basicSalary - totalDeduction();
    }
}